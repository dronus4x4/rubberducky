# USB-Rubber-Ducky-Toolkit
A toolkit for the USB Rubber ducky

![USB Rubber Ducky Toolkit](https://i.imgur.com/5HF0how.png)


##Video
You can find a video demonstrating this project on my YouTube channel [here.](https://www.youtube.com/watch?v=8mPSp8LkFNs)

##About
One day while working on a DuckyScript I realized how annoying it is to test DuckyScripts. A few hours later this project was born.
Right now the toolkit allows you to test your code by emulating what the ducky would do, a validator which can look at your code before you run it and tell you if there is compile errors and finally a easy-encoder which can encode a txt file to bin for you by clicking 1-button instead of going through CMD.

##Contributing 
If your interested in contributing and have any questions feel free to email me at 
meloche.hayden@gmail.com

[![forthebadge](http://forthebadge.com/images/badges/designed-in-ms-paint.svg)](http://forthebadge.com)
[![forthebadge](http://forthebadge.com/images/badges/powered-by-electricity.svg)](http://forthebadge.com)
